<?php 
session_start();

if (!isset($_SESSION['username'])) {
	header("Location:login.php");
		exit;
}
require'functions.php';
	if (isset($_POST['tambah'])){
   		if (tambah($_POST,$_FILES)>0) {
	   		echo "<script> alert('Data Berhasil Ditambahkan!');
	   		document.location.href='admin.php';
	   		</script>";
   		}else{
	   		"<script>
                alert('Data Gagal ditambahkan!');
                document.location.href = 'admin.php';
                </script>";
   		}
   	}
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Tambah Data Daftar Mobil</title>
	<style >
		body{background-image: url(../assets/img/ea.jpg);
                    text-align: center;
                    color:#556B2F;
                    font-size: 15px;
                    font:16px/28px arial sans-serif; 
                    background-size: 2300px;
                    background-repeat: repeat;
                }
            div{
			margin: 100px 10px 100px 450px;
			text-align: center;
			border: 1px solid black;
			background-color: #F08080;
			width: 300px;
			height: 400px;
			color: #556B2F;
			box-shadow: 20px 20px 50px black;
			font-family: arial;
		}
	</style>
</head>
<body>
	<div>
<form action="" method="post" enctype="multipart/form-data">
	<input type="hidden" name="id" value="<?=$mb['id'] ;?>">
	<label for="gambar">gambar</label>
	<br>
	<input type="file" name="gambar" id="gambar" >
	<br>
	<label for="nama">nama</label>
	<br>
	<input type="text" name="nama" id="nama" autofocus="on">
	<br>
	<label for="merk">merk</label>
	<br>
	<input type="text" name="merk" id="merk">
	<br>
	<label for="type">type</label>
	<br>
	<input type="text" name="type" id="type">
	<br>
	<label for="bahanbakar">bahanbakar</label>
	<br>
	<input type="text" name="bahanbakar" id="bahanbakar">
	<br>
	<label for="harga">harga</label>
	<br>
	<input type="text" name="harga" id="harga">
	<br>
	<button type="submit" name="tambah" >Tambah Data</button>
	<button> <a href="index.php">Kembali</a></button>
</form>
</div>
</body>
</html>