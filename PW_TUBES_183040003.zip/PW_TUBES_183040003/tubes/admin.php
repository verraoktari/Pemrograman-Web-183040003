<?php 
session_start();

if (!isset($_SESSION['username'])) {
	header("Location:login.php");
		exit;
}
require'functions.php';
if (isset($_POST['cari'])) {
		$keyword = $_POST['keyword'];
		$mobil = query("SELECT * FROM mobil WHERE
				nama LIKE '%$keyword%' OR
				merk LIKE '%$keyword%' OR
				type LIKE '%$keyword%' OR
				bahanbakar LIKE '%$keyword%' OR
				harga LIKE '%$keyword%'");
	}else{
		$mobil =query("SELECT * FROM mobil");
	 	 }


 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<title>Halaman Admin</title>
 		<style>
 		 body{background-image: url(../assets/img/iww.png);
                    text-align: center;
                    color:#556B2F;
                    font-size: 15px;
                    font:16px/28px arial sans-serif; 
                    background-size: 2300px;
                    background-repeat: repeat;
                }
                div{
                	text-align: center;
                }
 		div h1{
 			text-align: center;
 		}
 		div table{
 			text-align: center;
 			background-image: url(../assets/img/lolo.jpg);
 			  margin: 50px 50px 50px 150px;
 		}
 		div th{
 			background-color: grey; 
 		}
 		.form{
 			text-align: left;
 			 margin: 50px 50px 50px 150px;
 		}

 		.cari {
 			width: 100px;
 		}
 	</style> 
 </head>
 <body>
 	<div>
 		<div class="form">
  		<h1>Daftar  Nama Mobil	</h1>			
 		<br>	
 		<a href="tambah.php"><button>Tambah Data</button></a>
 		<form action="" method="post">	
		<input type="text" name="keyword"  size="40" autofocus placeholder="search..." autocomplete="off" id="keyword">
		<button type="submit" name="cari" id="tombol-cari"> Cari </button>
	<button><a href="logout.php">logout</a></button>
		</tr>
	</form>
</div>
<div id="container">	
 <table border="1px" cellpadding="2px">
 	<?php if (empty($mobil)): ?>
			<tr>
				<td colspan="7">
					<h1 align="center">Data Tidak Ditemukan</h1>
				</td>
			</tr>
		<?php else : ?>
 	<thead>
 		<tr>
 			<th>#</th>
 			<th>opsi</th>
 			<th>gambar</th>
 			<th width="150px">nama</th>
 			<th width="150px"> merk</th>
 			<th width="150px">type</th>
 			<th width="150px">bahan bakar</th>
 			<th width="150px">harga</th>
 		</tr>
 	</thead>
 	<tbody>
 		<?php $no=1; ?>
 		<?php foreach ($mobil as $mb) : ?>
 			<tr>
 				<td><?= $no++; ?></td>
 				<td>
 					<a href="hapus.php?id=<?=$mb['id'] ;?>"onclick="return confirm('anda yakin ingin menghapus data ini ');">Hapus</a>
 					 <a href="ubah.php?id=<?= $mb['id']; ?>">Ubah</a>
 				</td>
 				<td><img widht="300px" src="../assets/img/<?= $mb['gambar'] ;?>"></td>
 				<td><?= $mb['nama']; ?></td>
 				<td><?= $mb['merk']; ?></td>
 				<td><?= $mb['type']; ?></td>
 				<td><?= $mb['bahanbakar']; ?></td>
 				<td><?= $mb['harga']; ?></td>

 			</tr>
 	<?php endforeach; ?>
 	<?php endif ?>
 	</tbody>
 </table>
  </div>


</div>

 <script src="js/script_admin.js" ></script>
 </body>
 </html>