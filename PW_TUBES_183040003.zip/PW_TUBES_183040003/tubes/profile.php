<?php 
require'functions.php';

$id = $_GET['id'];
$mobil = query("SELECT * FROM mobil WHERE id = $id")[0];
?>


<!DOCTYPE html>
<html lang="en">
    <head>

        <title>profile</title>

<style >
    body{background-image: url(../assets/img/iww.png);
                    text-align: center;
                    color:#556B2F;
                    font-size: 15px;
               z     font:16px/28px arial sans-serif; 
                    background-size: 2300px;
                    background-repeat: repeat;
                }
                div table{
            text-align: center;
            background-image: url(../assets/img/lolo.jpg);
            margin: 50px 50px 50px 150px;
        }
                
</style>
    </head>
    <body>
        <div>
            <table border="1px" cellpadding="2px">
    
    <thead>
        <tr>
           
            <th>gambar</th>
            <th width="150px">nama</th>
            <th width="150px"> merk</th>
            <th width="150px">type</th>
            <th width="150px">bahan bakar</th>
            <th width="150px">harga</th>
        </tr>
    </thead>
    <tbody>
             <tr>     
                <td><img widht="300px" src="../assets/img/<?= $mobil['gambar'] ;?>"></td>
                <td><?= $mobil['nama']; ?></td>
                <td><?= $mobil['merk']; ?></td>
                <td><?= $mobil['type']; ?></td>
                <td><?= $mobil['bahanbakar']; ?></td>
                <td><?= $mobil['harga']; ?></td>

            </tr>
    
 
    </tbody>
 </table>
            <div class="tombol">
            <a href="index.php"><button>Kembali</button></a>
            </div>
       </div>
    </body>
</html>