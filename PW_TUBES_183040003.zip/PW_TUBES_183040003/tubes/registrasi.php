<?php 

require'functions.php';
if (isset($_POST["register"])) {
	
	if (registrasi($_POST) > 0 ) {
		  echo    "<script>
                alert('user baru berhasil ditambahkan!');
                 document.location.href='login.php';
                </script>";
    } 
}
 ?>




<!DOCTYPE html>
<html>
<head>
	<title>Halaman Registrasi</title>
	
	<style >
		body{background-image: url(../assets/img/ea.jpg);
                    text-align: center;
                    color:#556B2F;
                    font-size: 15px;
                    font:16px/28px arial sans-serif; 
                    background-size: 2300px;
                    background-repeat: repeat;
                }
            div{
			margin: 100px 10px 100px 450px;
			text-align: center;
			border: 1px solid black;
			background-color: #F08080;
			width: 300px;
			height: 500px;
			color: #556B2F;
			box-shadow: 20px 20px 50px black;
			font-family: arial;
		}
	
		label{
			display: block;
		}
	</style>
</head>
<body>
<div>
<h1>Halaman Registrasi</h1>

<form action="" method="post">

		<label for="username">username</label>
		<input type="text" name="username" id="username" required>
	<br>
		<label for="password">password</label>
		<input type="password" name="password" id="password" required>
	<br>
		<label for="password2">konfirmasi password</label>
		<input type="password" name="password2" id="password2" required>
	<br>
		<button type="submit" name="register">Register</button>
	

</form>
</div>

</body>
</html>