<?php 
function koneksi(){
$conn=mysqli_connect("localhost","root","", "pw_183040003")or die("koneksi ke DB gagal!");


return $conn;
}

function query($sql){
	$conn=koneksi();
	$results=mysqli_query($conn,"$sql");

	$rows=[];
	while ($row=mysqli_fetch_assoc($results)) {
		$rows[]=$row;

	};
	return $rows;
}


function tambah($data)

{
	$conn=koneksi();
	//ambil data dari tiap elemen form
	$nama=htmlspecialchars($data['nama']);
	$merk=htmlspecialchars($data['merk']);
	$type=htmlspecialchars($data['type']);
	$bahanbakar=htmlspecialchars($data['bahanbakar']);
	$harga=htmlspecialchars($data['harga']);

//upload gambar
	$gambar=upload();
	if(!$gambar){
		return false;
	}


	$querytambah="INSERT INTO mobil Values('','$gambar','$nama','$merk','$type','$bahanbakar','$harga')";

	mysqli_query($conn,$querytambah);
	return mysqli_affected_rows($conn);
}



function upload(){
	$namaFile=$_FILES['gambar']['name'];
	$ukuranFile=$_FILES['gambar']['size'];
	$error=$_FILES['gambar']['error'];
	$tmpName=$_FILES['gambar']['tmp_name'];

	//cek apakah tidak ada gambar yang di upload 
	if($error===4){
		echo "<script>
		alert('pilih gambar terlebih dahulu!');
		</script>";
	
return false;

}
//cek apakah yang diupload adalah gambar
$ekstensiGambarValid=['jpg','jpeg','png'];
$ekstensiGambar=explode('.' , $namaFile);
$ekstensiGambar=strtolower(end($ekstensiGambar));
if (!in_array($ekstensiGambar, $ekstensiGambarValid)) {
	echo "<script>
		alert('yang anda upload bukan gambar!');
		</script>";
		return false;
}
//cek jika ukuran terlalu besar 
if ($ukuranFile>1000000) {
	echo "<script>
		alert('ukuran file terlalu besar!');
		</script>";
		return false;
}
//lolos pengecekan,gambar siap di upload
//generate nama gambar baru
$namaFileBaru =uniqid();
$namaFileBaru .='.';
$namaFileBaru .=$ekstensiGambar;


move_uploaded_file($tmpName,'../assets/img/'.$namaFileBaru);

return $namaFileBaru;
}



function hapus($id){
	$conn=koneksi();
	mysqli_query($conn,"DELETE FROM mobil WHERE id =$id");
	return mysqli_affected_rows($conn);

}



function ubah($data){
	$conn=koneksi();

	$id=$data['id'];
	$gambarLama=htmlspecialchars($data['gambarLama']);
	//cek user pilih gambar baru atau tidak
	if ($_FILES['gambar']['error']===4) {
		$gambar=$gambarLama;
	}else{
		$gambar=upload();
	}
	

	$nama=htmlspecialchars($data['nama']);
	$merk=htmlspecialchars($data['merk']);
	$type=htmlspecialchars($data['type']);
	$bahanbakar=htmlspecialchars($data['bahanbakar']);
	$harga=htmlspecialchars($data['harga']);


	$queryubah="UPDATE mobil
	SET 
	gambar='$gambar',
	nama='$nama',
	merk='$merk',
	type='$type',
	bahanbakar='$bahanbakar',
	harga='$harga'
	WHERE id=$id";
	
	mysqli_query($conn,$queryubah);
	return mysqli_affected_rows($conn);
}




function registrasi($data){
$conn=koneksi();
$username=strtolower(stripslashes($data['username']));
$password=mysqli_real_escape_string($conn,$data['password']);
$password2=mysqli_real_escape_string($conn,$data['password2']);

//cek usernaame sudah ada atau belum
$result=mysqli_query ($conn,"SELECT username FROM user WHERE username='$username'");

if (mysqli_fetch_assoc($result)) {
	echo "<script>
		alert('username sudah trdaftar !');
		document.location.href='registrasi.php';
		</script>";
		return false;
}
//cek konfirmasi password
if ($password !==$password2) {
	echo "<script>
		alert('konfirmasi password tidak sesuai!');
		document.location.href='registrasi.php';
		</script>";
		return false;
}


//enskripsi password
$password =  password_hash($password,PASSWORD_DEFAULT);
$created_at = time();
//tambahkan userbaru kedatabase
mysqli_query($conn,"INSERT INTO user VALUES('','$username','$password', '$created_at')");
echo mysqli_error($conn);
return mysqli_affected_rows($conn);
}

?> 