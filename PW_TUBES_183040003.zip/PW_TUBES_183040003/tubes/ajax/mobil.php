<?php 	
require'../functions.php';
$keyword = $_GET['keyword'];

$query =	"SELECT * FROM mobil WHERE
                nama LIKE '%$keyword%' 
               ";
$mobil = query($query);

 ?>
   <h1 align = "center">PT.Verra Oktari</h1>
         

            <?php if (empty($mobil)): ?>
            <tr>
                <td colspan="7">
                    <h1 align="center">Data Tidak Ditemukan</h1>
                </td>
            </tr>
        <?php else : ?>
                <?php foreach($mobil as $mb) : ?>


                               
                                <div class="table">
                                    <img src="../assets/img/<?= $mb['gambar']; ?>" alt="">
                                   
                                        <h2><?= $mb['nama']; ?></h2>

                                    <a href="profile.php?id=<?= $mb["id"];?>" class="id"><button class="btn">Lihat Info Lebih Lanjut</button></a>
                                
                             </div>
                                    
                                    
                                <br>
                        <?php endforeach; ?>
             <?php endif ?>