<?php 	
require'../functions.php';
$keyword = $_GET['keyword'];

$query =	"SELECT * FROM mobil WHERE
                nama LIKE '%$keyword%' OR
                merk LIKE '%$keyword%' OR
                type LIKE '%$keyword%' OR
                bahanbakar LIKE '%$keyword%' OR
                harga LIKE '%$keyword%'";
$mobil = query($query);

 ?>
   <table border="1px" cellpadding="2px">
    <?php if (empty($mobil)): ?>
            <tr>
                <td colspan="7">
                    <h1 align="center">Data Tidak Ditemukan</h1>
                </td>
            </tr>
        <?php else : ?>
    <thead>
        <tr>
            <th>#</th>
            <th>opsi</th>
            <th>gambar</th>
            <th width="150px">nama</th>
            <th width="150px"> merk</th>
            <th width="150px">type</th>
            <th width="150px">bahan bakar</th>
            <th width="150px">harga</th>
        </tr>
    </thead>
    <tbody>
        <?php $no=1; ?>
        <?php foreach ($mobil as $mb) : ?>
            <tr>
                <td><?= $no++; ?></td>
                <td>
                    <a href="hapus.php?id=<?=$mb['id'] ;?>"onclick="return confirm('anda yakin ingin menghapus data ini ');">Hapus</a>
                     <a href="ubah.php?id=<?= $mb['id']; ?>">Ubah</a>
                </td>
                <td><img widht="300px" src="../assets/img/<?= $mb['gambar'] ;?>"></td>
                <td><?= $mb['nama']; ?></td>
                <td><?= $mb['merk']; ?></td>
                <td><?= $mb['type']; ?></td>
                <td><?= $mb['bahanbakar']; ?></td>
                <td><?= $mb['harga']; ?></td>

            </tr>
    <?php endforeach; ?>
    <?php endif ?>
    </tbody>
 </table>