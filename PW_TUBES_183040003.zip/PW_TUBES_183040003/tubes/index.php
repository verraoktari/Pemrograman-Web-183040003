<?php 



require'functions.php';
if (isset($_POST['cari'])) {
    $keyword = $_POST['keyword'];
    $mobil = query("SELECT * FROM mobil WHERE
        nama LIKE '%$keyword%' OR
        merk LIKE '%$keyword%' OR
        type LIKE '%$keyword%' OR
        bahanbakar LIKE '%$keyword%' OR
        harga LIKE '%$keyword%'");
  }else{
    $mobil =query("SELECT * FROM mobil");
     }


 ?>

 <!DOCTYPE html>
 <html>
     <head>
        <title>index tugas 3</title>
        <!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
      <!-- My css -->
      <link rel="stylesheet" href="css/style.css">
     
      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  </head>

        <style>
                .mb{
                    text-align: center;
                    color:lime;
                    font-size: 15px;
                    font:16px/28px arial sans-serif; 
                    background-size: 230px;
                    background-repeat: repeat;
                }
                 
                
                a:hover{
                    background-color:pink;
                    color: purple;
                }
   

        a{
            text-decoration : none;
            color : black;
        }
        .login{
            text-align: right;
        }
        .cari{
            text-align: right;
        }
        .table{
            margin: 50px 5px 5px 500px;
            text-align: center;
            border: 1px solid black;
            width: 300px;
            height: 350px;
            color: #556B2F;
            box-shadow: 20px 20px 50px black;
            font-family: arial;
        }
        </style>
 
 </head>

<body id="home" class="scrollspy">
 
           <div class="navbar-fixed">
           <nav class="lime  lime darken-3">
           <div class="container">
           <div class="nav-wrapper">
                  <a href="#" data-target="mobile-nav" class="sidenav-trigger"><i class="material-icons">menu</i></a>
          <ul class="right hide-on-med-and-down">
             <li><a href="#home">Home</a></li>
             <li><a href="#container">Mobil</a></li>
             <li><a href="#portfolio">Portfolio</a></li>
             <li><a href="#about">About Us</a></li>
             <li><a href="#Contact">Contact Us</a></li>  
             <li> 
           <div class="login">
                  <a href="login.php"><button class = "btn3">Login as Admin</button></a>
           </div>
            </li>
            <li> 
          <form action="" method="post"> 
                 <input type="text" name="keyword"  autofocus placeholder="search..." autocomplete="off" id="keyword">
                 <button type="submit" name="cari" id="tombol-cari">  </button>
          </form></li>
           </ul>
      </div>
      </div>
      </nav>
      </div>
     <!--akhir  navbar -->
      <!-- sidenav -->
      <ul class="sidenav" id="mobile-nav">
        <li><a href="#home">Home</a></li>
         <li><a href="#container">Mobil</a></li>
          <li><a href="#portfolio">Portfolio</a></li>
         <li><a href="#about">About us</a></li>
          <li><a href="#Contact">Contact Me</a></li> 
          <li> 
       
                  <a href="login.php"><button class = "btn3">Login as Admin</button></a>
         
            </li>
      </ul>
      <!-- akhir sidenav -->
      
       <!-- slider -->
      <div class="slider">
      <ul class="slides">
      <li>
             <img src="../assets/img/slider/sh.jpg"> 
             <div class="caption left-align">
             <h3>Welcome My Auto Verra</h3>
             <h5 class="blue-text text-lighten-3">Jual Beli Mobil,Tukar Tambah</h5>
      </div>
          </li>
          <li>
          <img src="../assets/img/slider/sj.jpg"> 
          <div class="caption right-align">
          <h3>Verra Oktari</h3>
         
      </div>
          </li>
          <li>
            <img src="../assets/img/slider/mb.png"> 
            <div class="caption center-align">
            
            </div>
            </li>
            </ul>
     </div>
      <!-- akhir slider -->
      <!-- Education-->
     <div id="container">
     <div class="parallax-container scrollspy">
      <div class="parallax"><img src="../assets/img/parallax/mb.png"></div>
  
  
 <div  class="mb">
            <h1 align = "center">PT.Verra Oktari</h1>
         

            <?php if (empty($mobil)): ?>
            <tr>
                <td colspan="7">
                    <h1 align="center">Data Tidak Ditemukan</h1>
                </td>
            </tr>
        <?php else : ?>
                <?php foreach($mobil as $mb) : ?>


                               
                                <div class="table">
                                    <img src="../assets/img/<?= $mb['gambar']; ?>" alt="">
                                   
                                        <h2><?= $mb['nama']; ?></h2>

                                    <a href="profile.php?id=<?= $mb["id"];?>" class="id"><button class="btn">Lihat Info Lebih Lanjut</button></a>
                                
                             </div>
                                    
                                    
                                <br>
                        <?php endforeach; ?>
             <?php endif ?>
        </div>
    </div>
      </div>
    </div>
  <!-- portfolio -->
         <section id="portfolio" class="portfolio scrollspy lime  white-text center">
         <div class="container">
          <h3 class="light center grey-text text-darken-3">Portfolio</h3> 
          <div class="row">
            <div class="col m3 s12">
             <img src="../assets/img/portfolio/1.jpg" class="responsive-img materialboxed"> 
            </div>
            <div class="col m3 s12">
             <img src="../assets/img/portfolio/2.jpeg" class="responsive-img materialboxed"> 
            </div>
            <div class="col m3 s12">
             <img src="../assets/img/portfolio/3.jpg" class="responsive-img materialboxed"> 
            </div>
            <div class="col m3 s12">
             <img src="../assets/img/portfolio/4.jpg" class="responsive-img materialboxed"> 
            </div>
          </div>
           <div class="row">
            <div class="col m3 s12">
             <img src="../assets/img/portfolio/5.jpg" class="responsive-img materialboxed"> 
            </div>
            <div class="col m3 s12">
             <img src="../assets/img/portfolio/6.jpg" class="responsive-img materialboxed"> 
            </div>
            <div class="col m3 s12">
             <img src="../assets/img/portfolio/7.jpg" class="responsive-img materialboxed"> 
            </div>
            <div class="col m3 s12">
             <img src="../assets/img/portfolio/8.jpg" class="responsive-img materialboxed"> 
            </div>
          </div>
         </div>  
         </section>
          <!-- akhir portfolio -->

       <!-- About me -->
      <section  id="about" class="about scrollspy lime darken-3 white-text ">
      <div class="container">
      <div class="row">
             <h3 class="center light grey-text text-darken-3">About Us</h3> 
             <div class="col m6 light">
             <h5>Hallo</h5>
             <p>Showroom Mobil Bangka Selatan .

              Jual Beli Mobil Cash atau Kredit, juga melayani tukar tambah mobil.</p>
             </div> 
             <div class="col m6 light">
            Verra MOBIL bergerak dalam bidang jual / beli mobil bekas. Dari pengalaman lebih dari 20 tahun di bidang otomotif, serta jaringan yang cukup luas khususnya di kota Bangka dan sekitarnya, membuat Astina Mobil bisa bertahan dan berkembang menjadi sebuah perusahaan otomotif yang cukup diperhitungkan dan bisa dipercaya.
             </div> 

      </div>   
      </div>
      </section>
       <!-- akhir About us -->
         <!-- Contact Us -->
          <div id="Contact" class="parallax-container scrollspy">
          <div class="parallax"><img src="../assets/img/wa.jpg"></div>
   

         
         <div class="container">
         <h3 class="light grey-text text-darken-3 center">Contact Us</h3>  
         <div class="row">
           <div class="col m5 s12"> 
          <div class="card-panel lime  center white-text">
           <i class="material-icons">email</i> 
         <h5>Contact Us</h5>
         <p>If you have questions, criticisms and suggestions, you can contact us through this form </p>
          </div>
         <ul class="collection with-header">
            <li class="collection-header"><h4>PT Verra Oktari</h4></li>
            
             <li class="collection-item">Jl.Menanti </li>
              <li class="collection-item">Sumatera Selatan,Indonesia</li>
                <li class="collection-item">email: PTverra@gmail.com</li>
                  <li class="collection-item">no hp: 0888 1212 3333 </li>
          </ul>
           </div>
          
        <div class="col m7 s12">
         <form>
          <div class=" card-panel">
            <h5>Please fill out this form</h5>
            <div class="input-field">
             <input type="text" name="name" id="name" required class="validate">
            <label for="name">name</label>
            </div>
            <div class="input-field">
             <input type="email" name="email" id="email" class="validate">
            <label for="email">email</label>
            </div>
            <div class="input-field">
            <input type="text" name="phone" id="phone">
            <label for="phone">phone</label>
            </div>
            <div class="input-field">
           <textarea name="message" id="message" class="materialize-textarea"></textarea>
           <label for="message">message</label>
            </div>
            <button type="submit" class="btn lime ">send</button>
            </div> 
            </form> 
            </div>
            </div>
            </div>   
            

      </div>
      </div>
            <!--akhir  Contact Us -->
                        <!-- footer -->
            <footer class="lime darken-3 white-text center">
              <p class="flow-text">Verra Oktari Universitas Pasundan. Copyrigt 2018. </p>
            </footer>
            <!-- akhir footer -->
 <script type="text/javascript" src="js/materialize.min.js"  ></script>
 <script src="js/script.js" ></script>
 <script > const sideNav= document.querySelectorAll('.sidenav');
            M.Sidenav.init(sideNav);

          const slider= document.querySelectorAll('.slider');
            M.Slider.init(slider,{
              indicators:false,
              height:500,
              transition:600,
              interval:3000
            });

          const parallax= document.querySelectorAll('.parallax');
            M.Parallax.init(parallax);

               const materialbox= document.querySelectorAll('.materialboxed');
              M.Materialbox.init(materialbox);


             const scroll= document.querySelectorAll('.scrollspy');
            M.ScrollSpy.init(scroll,{
              scrollOffset:50
            });


       </script>
 </body>
 </html>




























