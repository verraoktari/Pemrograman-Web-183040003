<?php 
session_start();


if (isset($_SESSION['username'])) {
	header("Location:admin.php");
		exit;


}
require'functions.php';
$conn = koneksi();
if (isset($_POST['login'])) {
	$username=$_POST['username'];
	$password=$_POST['password'];

	$cek_user=mysqli_query($conn,"SELECT * FROM user WHERE username = '$username'");
	
	if (mysqli_num_rows($cek_user)==1) {
		
//cek user
		$user= mysqli_fetch_assoc($cek_user);

		if (password_verify($password,$user['password'])) {
			$_SESSION['username']=$username;
			header('location:admin.php');
			exit;
		}else{
			$error='password salah ';
		}


		}else{
	//login gagal
	$error='Username/Password Salah !';
	
}
}

 ?>



<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<style>
body{background-image: url(../assets/img/ea.jpg);
                    text-align: center;
                    color:#808000;
                    font-size: 15px;
                    font:16px/28px arial sans-serif; 
                    background-size: 2300px;
                    background-repeat: repeat;
                }
		div img	{
			width: 100px;
			height: 100px;
			border-radius: 50%;
		}
		div{
			margin: 100px 10px 100px 450px;
			text-align: center;
			border: 1px solid black;
			background-color: #F08080;
			width: 300px;
			height: 500px;
			color: #556B2F;
			box-shadow: 20px 20px 50px black;
			font-family: arial;
		}
		div button{
			text-align: left;
		}
	</style>
</head>
<body>

<div>
<h3>Login Admin</h3>
<br>
<img src="../assets/img/uhu.jpg">
<br>
<?php if (isset($error)): ?>
	<p style="color: red;font-style: italic;"><?= $error; ?></p>
<?php endif ;?>
<form action="" method="post">
	
			<label>Username : </label> <br>
			<input type="text" name="username">
		<br>
			<label>Password :</label><br>
			<input type="password" name="password">
		<br>
			<button type="submit" name="login">Login</button>
		
</form>
<a href="registrasi.php">registrasi</a>
</div>
</body>
</html>