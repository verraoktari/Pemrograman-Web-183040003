<?php 
session_start();

if (!isset($_SESSION['username'])) {
	header("Location:login.php");
		exit;
}
require'functions.php';
$id= $_GET['id'];
$mb= query("SELECT * FROM mobil WHERE id = $id")[0];

	if(isset($_POST['ubah'])){
    if(ubah($_POST)>0){
        echo    "<script>
                alert('Data Berhasil diubah!');
                document.location.href = 'admin.php';
                </script>";
    } else {
                "<script>
                alert('Data Gagal diubah!');
                document.location.href = 'admin.php';
                </script>";
    }
}  	
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Ubah Data Daftar Mobil</title>
	<style>
		body{background-image: url(../assets/img/ea.jpg);
                    text-align: center;
                    color:#556B2F;
                    font-size: 15px;
                    font:16px/28px arial sans-serif; 
                    background-size: 2300px;
                    background-repeat: repeat;
                }
            div{
			margin: 100px 10px 100px 450px;
			text-align: center;
			border: 1px solid black;
			background-color: #F08080;
			width: 300px;
			height: 600px;
			color: #556B2F;
			box-shadow: 20px 20px 50px black;
			font-family: arial;
		}
	</style>
</head>
<body>
	<div>
		<form action="" method="post" enctype="multipart/form-data">
	<input type="hidden" name="id" value="<?= $mb['id'] ;?>">
	<input type="hidden" name="gambarLama" value="<?= $mb['gambar'] ;?>">
	<label for="gambar">gambar</label> 
	<br>
	<img src="../assets/img/<?= $mb['gambar'] ;?>">
	<br>
	<input type="file" name="gambar" id="gambar">
	<br>
	<label for="nama">nama</label>
	<br>
	<input type="text" name="nama" id="nama" autofocus="on" value="<?= $mb['nama'];?>">
	<br>
	<label for="merk">merk</label>
	<br>
	<input type="text" name="merk" id="merk" value="<?= $mb['merk'];?>">
	<br>
	<label for="type">type</label>
	<br>
	<input type="text" name="type" id="type" value="<?= $mb['type'];?>">
	<br>
	<label for="bahanbakar">bahanbakar</label>
	<br>
	<input type="text" name="bahanbakar" id="bahanbakar" value="<?= $mb['bahanbakar'];?>">
	<br>
	<label for="harga">harga</label>
	<br>
	<input type="text" name="harga" id="harga" value="<?= $mb['harga'];?>">
	<br>
	<button type="submit" name="ubah" >Ubah Data</button>
	<button> <a href="index.php">Kembali</a></button>
</form>
</div>
</body>
</html>